import React, { useState } from "react";

const Filters = (props) => {
  const { filters, onFilterChange } = props;
  const [isVisible, setIsVisible] = useState(false);

  const [data, setData] = React.useState(() => [...filters]);

  const handleChange = (e, index, type, valueType) => {
    console.log(e.target.value);
    const temp = data;
    if (type === 'text') {
        temp[index].value = e.target.value;
    } else {
        temp[index][valueType] = e.target.value;
    }
    
    setData(() => [...temp]);
    //console.log(filters);
  }

  const applyFilters = () => {
    setIsVisible(false)
    onFilterChange(data);
  }

  const toggleFilters = () => {
    setIsVisible(!isVisible);
}   

  return (
    <div className={'filter-container'}>
        <button onClick={toggleFilters}>Filters</button>
        {isVisible ? 
            <div className={'column-modal'}>
                {data.map((filter, index) => (
                    <div key={filter.field}>
                        <label className={'label'}>{filter.label}</label>
                        {filter.type === 'text' ?
                            <input type={filter.type} value={filter.value} onChange={(e) => handleChange(e, index)}/>
                            :
                            <>
                                <input type={filter.type} value={filter.fromValue} onChange={(e) => handleChange(e, index, filter.type, 'fromValue')}/>
                                <input type={filter.type} value={filter.toValue} onChange={(e) => handleChange(e, index, filter.type, 'toValue')}/>
                            </>
                        }
                        
                    </div>
                ))}
                <div className={'button-wrapper'}>
                    <button onClick={applyFilters} > Apply </button>
                </div>
            </div>
            : 
            <></>
        }
        
    </div>
  );
};

export default Filters;
