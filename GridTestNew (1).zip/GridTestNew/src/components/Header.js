import React from "react";
import Columns from "./Columns";
import Filters from "./Filters";

const Header = (props) => {
  const { visibleFields, onHandleColChange, filters, onFilterChange } = props;
  return (
    <div className={'header-container'}>
        <Columns onHandleColChange={onHandleColChange} visibleFields={visibleFields}></Columns>
        <Filters filters={filters} onFilterChange={onFilterChange}></Filters>
        <div className={'export-container'}>
            <button>Export</button>
        </div>
    </div>
  );
};

export default Header;
