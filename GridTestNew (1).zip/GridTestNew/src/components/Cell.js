import React, {useState} from "react";
import classnames from "classnames";

const Cell = (props) => {
  const { children, className, grow = false, isEditable, handleInputChange } = props;
  const [showInput, setShowInput] = useState(false);

  const toggleEdit = (isText, e) => {
    if (isEditable && isText) {
      setShowInput(true);
    } else if (!isText && e?.keyCode === 13) {
      setShowInput(false);
    }
  }

  const handleChange = (e) => {
    handleInputChange(e.target.value);
  }

  return (
    <div className={classnames("cell", className, { grow })}>
      {!showInput ? 
        <span onDoubleClick={() => toggleEdit(true)}>{children}</span>
        :
        <input value={children} onChange={(e) => handleChange(e)} onKeyDown={(e) => toggleEdit(false, e)} />
      }
    </div>
  );
};

export default Cell;
