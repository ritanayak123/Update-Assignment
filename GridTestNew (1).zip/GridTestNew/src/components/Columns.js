import React, { useState } from "react";


const Columns = (props) => {
    const { visibleFields, onHandleColChange } = props;
    const [isVisible, setIsVisible] = useState(false);

    const toggleColumnFilter = () => {
        setIsVisible(!isVisible);
    }

    const onSelectToggle = (index) => {
        const temp = visibleFields;
        temp[index].isVisible = !temp[index].isVisible;
        onHandleColChange(temp);
    }

    

    return (
        <div className={'column-container'}>
            <button onClick={() => toggleColumnFilter()}>Columns</button>
            {isVisible ? 
                <div className={'column-modal'}>
                    {visibleFields.map((field, index) => (
                        <div key={field.field}>
                            <input type="checkbox" checked={field.isVisible} onChange={() => onSelectToggle(index)} />
                            <label>{field.label}</label>
                        </div>
                    ))}
                </div>
                :
                <></>
            }
        </div>
    );
};

export default Columns;
