import "./App.css";
import React, {useEffect} from "react";
import moment from "moment";
import Table from "./components/Table";
import Cell from "./components/Cell";
import Row from "./components/Row";
import Header from "./components/Header";

function App() {
  const demoData = [
    {
      id: 0,
      title: "Tagtune",
      division: "Accounting",
      project_owner: "Kevin Snyder",
      budget: 20614.14,
      status: "archived",
      created: "2021-09-14",
      modified: "2021-10-02",
    },
    {
      id: 1,
      title: "Oyoyo",
      division: "Administration",
      project_owner: "Eugene Brown",
      budget: 22106.44,
      status: "new",
      created: "2021-07-17",
      modified: "2021-07-18",
    },
    {
      id: 2,
      title: "Lajo",
      division: "Marketing",
      project_owner: "Killgore Trout",
      budget: 15481.27,
      status: "working",
      created: "2021-07-19",
      modified: "2021-09-17",
    },
    {
      id: 3,
      title: "Blognation",
      division: "Administration",
      project_owner: "Richard Henry",
      budget: 24017.98,
      status: "working",
      created: "2021-08-03",
      modified: "2021-09-17",
    },
    {
      id: 4,
      title: "Vinte",
      division: "Administration",
      project_owner: "Michelle Webb",
      budget: 12935.84,
      status: "working",
      created: "2021-08-05",
      modified: "2021-09-15",
    },
    {
      id: 5,
      title: "Aibox",
      division: "Administration",
      project_owner: "Killgore Trout",
      budget: 15991.78,
      status: "working",
      created: "2021-09-03",
      modified: "2021-10-02",
    },
    {
      id: 61,
      title: "Buzzdog",
      division: "Administration",
      project_owner: "Michelle Webb",
      budget: 22610.09,
      status: "archived",
      created: "2021-07-26",
      modified: "2021-10-01",
    },
    {
      id: 6,
      title: "Plambee",
      division: "Sales",
      project_owner: "Michelle Webb",
      budget: 14229.02,
      status: "archived",
      created: "2021-09-14",
      modified: "2021-10-01",
    },
    {
      id: 7,
      title: "Photobug",
      division: "Administration",
      project_owner: "James Holden",
      budget: 10959.29,
      status: "working",
      created: "2021-09-03",
      modified: "2021-09-18",
    },
    {
      id: 8,
      title: "Quimm",
      division: "Marketing",
      project_owner: "James Holden",
      budget: 14139.38,
      status: "delivered",
      created: "2021-08-02",
      modified: "2021-09-26",
    },
    {
      id: 9,
      title: "Innojam",
      division: "Sales",
      project_owner: "Eugene Brown",
      budget: 24318.05,
      status: "working",
      created: "2021-09-13",
      modified: "2021-09-20",
    },
    {
      id: 10,
      title: "Jaxworks",
      division: "Production",
      project_owner: "Michelle Webb",
      budget: 15054.27,
      status: "new",
      created: "2021-08-12",
      modified: "2021-08-13",
    },
    {
      id: 11,
      title: "Skyble",
      division: "Accounting",
      project_owner: "Richard Henry",
      budget: 13810.1,
      status: "delivered",
      created: "2021-07-12",
      modified: "2021-09-21",
    },
    {
      id: 12,
      title: "Photobean",
      division: "Marketing",
      project_owner: "Michelle Webb",
      budget: 12637.95,
      status: "working",
      created: "2021-08-24",
      modified: "2021-09-15",
    },
    {
      id: 13,
      title: "Topicware",
      division: "Administration",
      project_owner: "Eugene Brown",
      budget: 9667.52,
      status: "working",
      created: "2021-08-01",
      modified: "2021-09-29",
    },
    {
      id: 14,
      title: "Buzzster",
      division: "Production",
      project_owner: "Nicole Smith",
      budget: 14657.54,
      status: "working",
      created: "2021-08-09",
      modified: "2021-09-18",
    },
    {
      id: 15,
      title: "Twinte",
      division: "Administration",
      project_owner: "Kevin Snyder",
      budget: 17729.37,
      status: "delivered",
      created: "2021-09-09",
      modified: "2021-09-18",
    },
    {
      id: 16,
      title: "Blognation 1",
      division: "Production",
      project_owner: "Eugene Brown",
      budget: 19540.82,
      status: "archived",
      created: "2021-07-21",
      modified: "2021-09-22",
    },
    {
      id: 17,
      title: "Flashdog",
      division: "Production",
      project_owner: "Michelle Webb",
      budget: 24870.61,
      status: "working",
      created: "2021-07-05",
      modified: "2021-10-02",
    },
    {
      id: 18,
      title: "Yakijo",
      division: "Accounting",
      project_owner: "Killgore Trout",
      budget: 23533.54,
      status: "working",
      created: "2021-08-12",
      modified: "2021-10-01",
    },
    {
      id: 19,
      title: "Quatz",
      division: "Sales",
      project_owner: "Richard Henry",
      budget: 23639.65,
      status: "archived",
      created: "2021-07-19",
      modified: "2021-09-19",
    },
    {
      id: 20,
      title: "Dabjam",
      division: "Marketing",
      project_owner: "Kevin Snyder",
      budget: 14356.55,
      status: "new",
      created: "2021-08-22",
      modified: "2021-08-23",
    },
    {
      id: 21,
      title: "Meetz",
      division: "Sales",
      project_owner: "Kevin Snyder",
      budget: 13882.22,
      status: "delivered",
      created: "2021-08-26",
      modified: "2021-10-01",
    },
    {
      id: 22,
      title: "Flipopia",
      division: "Marketing",
      project_owner: "Eugene Brown",
      budget: 10306.87,
      status: "delivered",
      created: "2021-08-11",
      modified: "2021-09-17",
    },
    {
      id: 23,
      title: "Quaxo",
      division: "Administration",
      project_owner: "Nicole Smith",
      budget: 13945.69,
      status: "archived",
      created: "2021-07-13",
      modified: "2021-09-21",
    },
    {
      id: 24,
      title: "Trunyx",
      division: "Production",
      project_owner: "Nicole Smith",
      budget: 23136.21,
      status: "delivered",
      created: "2021-09-03",
      modified: "2021-09-19",
    },
    {
      id: 25,
      title: "Dabtype",
      division: "Marketing",
      project_owner: "Richard Henry",
      budget: 22000.98,
      status: "archived",
      created: "2021-08-26",
      modified: "2021-09-28",
    },
    {
      id: 26,
      title: "Meetz 1",
      division: "Marketing",
      project_owner: "Eugene Brown",
      budget: 17620.23,
      status: "new",
      created: "2021-09-08",
      modified: "2021-09-09",
    },
    {
      id: 27,
      title: "Kimia",
      division: "Sales",
      project_owner: "Richard Henry",
      budget: 12061.73,
      status: "archived",
      created: "2021-08-31",
      modified: "2021-09-29",
    },
    {
      id: 28,
      title: "Dazzlesphere",
      division: "Accounting",
      project_owner: "Eugene Brown",
      budget: 21443.97,
      status: "archived",
      created: "2021-07-20",
      modified: "2021-10-01",
    },
  ];

  const ALL_FIELDS = [
    {field: "title", label: 'Title', isEditable: false},
    {field: "division", label: 'Division', isEditable: false},
    {field: "project_owner", label: 'Project Owner', isEditable: true},
    {field: "budget", label: 'Budget', isEditable: true},
    {field: "status", label: 'Status', isEditable: true},
    {field: "created", label: 'Created', isEditable: false},
    {field: "modified", label: 'Modified', isEditable: false},
  ];

  const initialFilter = [
      {field: 'title', value: '', type: 'text', label: 'Title'},
      {field: 'division', value: '', type: 'text', label: 'Division'},
      {field: 'project_owner', value: '', type: 'text', label: 'Project Owner'},
      {field: 'budget', value: '', type: 'text', label: 'Budget'},
      {field: 'status', value: '', type: 'text', label: 'Status'},
      {field: 'created', toValue: '', fromValue: '', type: 'date', label: 'Created'},
      {field: 'modified', toValue: '', fromValue: '', type: 'date', label: 'Modified'},
    ];

  const [rows, setRows] = React.useState(() => [...demoData]);
  const [filters, setFilters] = React.useState(() => [...initialFilter]);

  const [visibleFields, setVisibleFields] = React.useState(() => [
    {
      isVisible: true,
      field: '',
      label: ''
    }
  ]);

  useEffect(() => {
    const temp = ALL_FIELDS.map(field => {
        const obj = {
            isVisible: true,
            field: field.field,
            label: field.label,
            isEditable: field.isEditable
        }
        return obj;
    });
    setVisibleFields(() => [...temp]);
  }, []);

  const handleColumnChange = (data) => {
    setVisibleFields(() => [...data]);
  };

  const handleFilterChange = (data) => {
    setFilters(() => [...data]);
    const appliedFilters = data.filter(filter => {
      if (filter.value || (filter.toValue && filter.fromValue)) {
        return true;
      } else {
        return false;
      }
    });
    const filterObj = getFilterObj(appliedFilters);
    const temp = demoData.filter(row => {
      let flag = false;
      Object.keys(filterObj).forEach(field => {
        if (field.type === 'text') {
          if (row[field].indexOf(filterObj[field]) !== -1) {
            flag = true;
            return;
          }
        } else {
          const dates = filterObj[field].split('+');
          var compareDate = moment(row[field], "YYYY-MM-DD");
          var startDate = moment(dates[0], "YYYY-MM-DD");
          var endDate = moment(dates[1], "YYYY-MM-DD");
          if (compareDate > startDate && compareDate < endDate) {
            flag = true;
            return;
          }
        }
      });
      return flag;
    });
    setRows(() => [...temp]);
  };

  const getFilterObj = (appliedFilters) => {
    const obj = {};
    appliedFilters.forEach(filter => {
      obj[filter.field] = filter.type === 'text' ? filter.value : filter.fromValue + '+' + filter.toValue;
    });
    return obj;
  }

  const handleChange = (value, field, index) => {
    const temp = rows;
    temp[index][field] = value;
    setRows(() => [...temp]);
  }

  return (
    <div className="main-container" style={{ height: 520, width: "82%" }}>
      <Header onFilterChange={(data) => handleFilterChange(data)} filters={filters} onHandleColChange={(data) => handleColumnChange(data)} visibleFields={visibleFields}></Header>
      <Table>
        <div>
          <Row wrapper>
            {visibleFields.map(col => (
              col.isVisible ? <Cell key={col.field} isEditable={false} className="table-col-heder">{col.label}</Cell> : <></>
            ))}
          </Row>
          <div className={'table-rows'}>
            {rows.map((row, index) => (
              <Row wrapper key={row.title}>
                {visibleFields.map(col => (
                  col.isVisible ? <Cell key={col.field} handleInputChange={(value) => handleChange(value, col.field, index)} isEditable={col.isEditable} data={true}>{row[col.field]}</Cell> : <></>
                ))}
                <Cell>
                  <button>Details</button>
                </Cell>
              </Row>
            ))}
          </div>
        </div>
      </Table>
      <div className="new-row">
        <input placeholder="Title" />
        <input placeholder="Division" />
        <input placeholder="Project Owner" />
        <input placeholder="Budget" />
        <input placeholder="Status" />
        <input type="date" placeholder="Created Date" />
        <input type="date" placeholder="Modified Date" />
        <div className={'button-wrapper'}>
          <button>Add Row</button>
        </div>
      </div>
    </div>
  );
}

export default App;
